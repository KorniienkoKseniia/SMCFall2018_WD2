# SMCFall2018_WD2
Code examples from Web Design 2 class for Fall 2018 at Santa Monica College.
